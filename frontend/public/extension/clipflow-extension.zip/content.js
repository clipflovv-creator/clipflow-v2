"use strict";
(() => {
  // src/protocol.ts
  var PAGE_SOURCE = "clipflow-page";
  var EXT_SOURCE = "clipflow-ext";

  // src/content.ts
  var PLATFORMS = true ? ["youtube", "instagram", "twitter", "twitch"] : ["instagram", "twitter", "twitch"];
  var RELAY_URL = chrome.runtime.getURL("relay.html");
  function reply(id, data) {
    window.postMessage({ source: EXT_SOURCE, id, ...data }, window.location.origin);
  }
  window.addEventListener("message", async (e) => {
    if (e.source !== window || e.data?.source !== PAGE_SOURCE) return;
    if (!chrome.runtime?.id) return;
    const { id, request } = e.data;
    if (request.type === "ping") {
      reply(id, { event: "pong", version: "1.0.0", build: "full", platforms: PLATFORMS, relayUrl: RELAY_URL });
      return;
    }
    try {
      await chrome.runtime.sendMessage({ target: "bg", type: "ensureOffscreen" });
    } catch (err) {
      reply(id, { event: "error", message: `Extension not ready: ${err?.message || err}` });
      return;
    }
    console.log("[ClipFlow content] \u2192", request.type, request);
    const port = chrome.runtime.connect({ name: "job" });
    port.onMessage.addListener((msg) => {
      reply(id, msg);
      if (["done", "error", "info", "streams", "captions", "ack"].includes(msg.event)) port.disconnect();
    });
    port.postMessage(request);
  });
  reply("announce", { event: "pong", version: "1.0.0", build: "full", platforms: PLATFORMS, relayUrl: RELAY_URL });
})();
