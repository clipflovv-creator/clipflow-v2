// <define:__SITE_ORIGINS__>
var define_SITE_ORIGINS_default = ["https://clipflow-lake.vercel.app", "http://localhost:5173", "http://localhost:3000", "http://127.0.0.1:5173", "https://clipflow.cliy.me", "https://clipflow-v2.vercel.app"];

// src/background.ts
var OFFSCREEN_URL = "offscreen.html";
async function ensureOffscreen() {
  const existing = await chrome.runtime.getContexts({ contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT] });
  if (existing.length) return;
  try {
    await chrome.offscreen.createDocument({
      url: OFFSCREEN_URL,
      reasons: [chrome.offscreen.Reason.WORKERS, chrome.offscreen.Reason.BLOBS],
      justification: "Download and mux video on the user device with ffmpeg.wasm"
    });
  } catch (err) {
    if (!String(err?.message).includes("single offscreen")) throw err;
  }
}
var HEADER_RULES = [
  { domains: ["instagram.com", "cdninstagram.com", "fbcdn.net"], origin: "https://www.instagram.com" },
  { domains: ["twitch.tv", "ttvnw.net", "jtvnw.net", "cloudfront.net"], origin: "https://www.twitch.tv" },
  { domains: ["twimg.com"], origin: "https://x.com" },
  ...true ? [{ domains: ["youtube.com", "googlevideo.com"], origin: "https://www.youtube.com" }] : []
];
async function installHeaderRules() {
  const siteHosts = define_SITE_ORIGINS_default.map((o) => new URL(o).hostname);
  const conditions = (domains) => [
    { requestDomains: domains, tabIds: [chrome.tabs.TAB_ID_NONE] },
    { requestDomains: domains, initiatorDomains: [chrome.runtime.id] },
    {
      requestDomains: domains,
      initiatorDomains: siteHosts,
      resourceTypes: [chrome.declarativeNetRequest.ResourceType.MEDIA, chrome.declarativeNetRequest.ResourceType.IMAGE]
    }
  ];
  const rules = HEADER_RULES.flatMap((r) => conditions(r.domains).map((condition) => ({ r, condition }))).map(({ r, condition }, i) => ({
    id: i + 1,
    priority: 1,
    action: {
      type: chrome.declarativeNetRequest.RuleActionType.MODIFY_HEADERS,
      requestHeaders: [
        { header: "referer", operation: chrome.declarativeNetRequest.HeaderOperation.SET, value: `${r.origin}/` },
        { header: "origin", operation: chrome.declarativeNetRequest.HeaderOperation.SET, value: r.origin }
      ]
    },
    condition
  }));
  await chrome.declarativeNetRequest.updateSessionRules({
    removeRuleIds: (await chrome.declarativeNetRequest.getSessionRules()).map((r) => r.id),
    addRules: rules
  });
}
chrome.runtime.onInstalled.addListener(() => void installHeaderRules());
chrome.runtime.onStartup.addListener(() => void installHeaderRules());
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.target !== "bg") return;
  (async () => {
    switch (msg.type) {
      case "ensureOffscreen":
        await installHeaderRules();
        await ensureOffscreen();
        return { ok: true };
      case "getCookies": {
        const all = await chrome.cookies.getAll({ url: msg.url });
        return { header: all.map((c) => `${c.name}=${c.value}`).join("; ") };
      }
      case "getCookie": {
        const c = await chrome.cookies.get({ url: msg.url, name: msg.name });
        return { value: c?.value ?? null };
      }
      case "saveFile":
        console.log(`[ClipFlow bg] saving ${msg.filename}`);
        return saveAndWait(msg.url, msg.filename);
    }
  })().then(sendResponse, (err) => sendResponse({ error: String(err?.message || err) }));
  return true;
});
function saveAndWait(url, filename) {
  return new Promise((resolve) => {
    let downloadId;
    const early = [];
    const finish = (r) => {
      chrome.downloads.onChanged.removeListener(onChanged);
      chrome.runtime.sendMessage({ target: "offscreen", type: "revoke", url }).catch(() => {
      });
      resolve(r);
    };
    const onChanged = (d) => {
      if (downloadId === void 0) {
        early.push(d);
        return;
      }
      if (d.id !== downloadId) return;
      if (d.state?.current === "complete") {
        console.log(`[ClipFlow bg] saved #${downloadId}`);
        finish({ downloadId });
      } else if (d.state?.current === "interrupted") finish({ error: `Saving failed: ${d.error?.current || "interrupted"}` });
    };
    chrome.downloads.onChanged.addListener(onChanged);
    let settled = false;
    const attempt = (name, retry) => {
      const timer = setTimeout(() => {
        if (settled) return;
        console.warn(`[ClipFlow bg] download of "${name}" did not start in 15s${retry ? ", retrying" : ""}`);
        if (retry) attempt(asciiName(name), false);
        else {
          settled = true;
          finish({ error: "Chrome did not start the download. Please click Download again." });
        }
      }, 15e3);
      chrome.downloads.download({ url, filename: name, saveAs: false, conflictAction: "uniquify" }).then(
        (id) => {
          clearTimeout(timer);
          if (settled) {
            chrome.downloads.cancel(id).catch(() => {
            });
            return;
          }
          settled = true;
          downloadId = id;
          early.forEach(onChanged);
        },
        (err) => {
          clearTimeout(timer);
          if (settled) return;
          settled = true;
          console.warn("[ClipFlow bg] chrome.downloads failed:", err?.message || err);
          finish({ error: `Saving failed: ${err?.message || err}` });
        }
      );
    };
    attempt(filename, true);
  });
}
function asciiName(name) {
  const dot = name.lastIndexOf(".");
  const base = (dot > 0 ? name.slice(0, dot) : name).replace(/[^\x20-\x7E]/g, "").replace(/\s+/g, " ").trim() || "ClipFlow clip";
  return dot > 0 ? base + name.slice(dot) : base;
}
chrome.runtime.onInstalled.addListener(async () => {
  const matches = chrome.runtime.getManifest().content_scripts?.[0]?.matches ?? [];
  const tabs = await chrome.tabs.query({ url: matches });
  for (const tab of tabs) {
    if (!tab.id) continue;
    chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] }).then(() => console.log(`[ClipFlow bg] injected into open tab ${tab.url}`)).catch((err) => console.warn("[ClipFlow bg] inject failed:", tab.url, err?.message));
  }
});
chrome.declarativeNetRequest.onRuleMatchedDebug?.addListener((info) => {
  console.log(`[ClipFlow bg] header rule ${info.rule.ruleId} applied \u2192 ${info.request.url.split("?")[0]}`);
});
chrome.declarativeNetRequest.getSessionRules().then((rules) => console.log(`[ClipFlow bg] ${rules.length} header rules active`));
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiPGRlZmluZTpfX1NJVEVfT1JJR0lOU19fPiIsICIuLi8uLi9zcmMvYmFja2dyb3VuZC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiW1wiaHR0cHM6Ly9jbGlwZmxvdy1sYWtlLnZlcmNlbC5hcHBcIixcImh0dHA6Ly9sb2NhbGhvc3Q6NTE3M1wiLFwiaHR0cDovL2xvY2FsaG9zdDozMDAwXCIsXCJodHRwOi8vMTI3LjAuMC4xOjUxNzNcIixcImh0dHBzOi8vY2xpcGZsb3cuY2xpeS5tZVwiLFwiaHR0cHM6Ly9jbGlwZmxvdy12Mi52ZXJjZWwuYXBwXCJdIiwgIi8vIFNlcnZpY2Ugd29ya2VyOiBvd25zIHRoZSBvZmZzY3JlZW4gZG9jdW1lbnQsIGhlYWRlciBydWxlcywgY29va2llcyBhbmQgY2hyb21lLmRvd25sb2Fkcy5cclxuLy8gQWxsIGZldGNoaW5nIGFuZCBwcm9jZXNzaW5nIHJ1bnMgaW4gdGhlIG9mZnNjcmVlbiBkb2N1bWVudCAob2Zmc2NyZWVuLnRzKS5cclxuXHJcbmNvbnN0IE9GRlNDUkVFTl9VUkwgPSAnb2Zmc2NyZWVuLmh0bWwnO1xyXG5cclxuYXN5bmMgZnVuY3Rpb24gZW5zdXJlT2Zmc2NyZWVuKCkge1xyXG4gIGNvbnN0IGV4aXN0aW5nID0gYXdhaXQgY2hyb21lLnJ1bnRpbWUuZ2V0Q29udGV4dHMoeyBjb250ZXh0VHlwZXM6IFtjaHJvbWUucnVudGltZS5Db250ZXh0VHlwZS5PRkZTQ1JFRU5fRE9DVU1FTlRdIH0pO1xyXG4gIGlmIChleGlzdGluZy5sZW5ndGgpIHJldHVybjtcclxuICB0cnkge1xyXG4gICAgYXdhaXQgY2hyb21lLm9mZnNjcmVlbi5jcmVhdGVEb2N1bWVudCh7XHJcbiAgICAgIHVybDogT0ZGU0NSRUVOX1VSTCxcclxuICAgICAgcmVhc29uczogW2Nocm9tZS5vZmZzY3JlZW4uUmVhc29uLldPUktFUlMsIGNocm9tZS5vZmZzY3JlZW4uUmVhc29uLkJMT0JTXSxcclxuICAgICAganVzdGlmaWNhdGlvbjogJ0Rvd25sb2FkIGFuZCBtdXggdmlkZW8gb24gdGhlIHVzZXIgZGV2aWNlIHdpdGggZmZtcGVnLndhc20nLFxyXG4gICAgfSk7XHJcbiAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcclxuICAgIGlmICghU3RyaW5nKGVycj8ubWVzc2FnZSkuaW5jbHVkZXMoJ3NpbmdsZSBvZmZzY3JlZW4nKSkgdGhyb3cgZXJyO1xyXG4gIH1cclxufVxyXG5cclxuLy8gQ0ROcyBjaGVjayBSZWZlcmVyL09yaWdpbjsgZmV0Y2goKSBjYW4ndCBzZXQgdGhlbSwgc28gcmV3cml0ZSB0aGVtIGZvciBleHRlbnNpb24tb3JpZ2luYXRlZCByZXF1ZXN0cyAodGFiSWQgLTEpLlxyXG5jb25zdCBIRUFERVJfUlVMRVM6IEFycmF5PHsgZG9tYWluczogc3RyaW5nW107IG9yaWdpbjogc3RyaW5nIH0+ID0gW1xyXG4gIHsgZG9tYWluczogWydpbnN0YWdyYW0uY29tJywgJ2Nkbmluc3RhZ3JhbS5jb20nLCAnZmJjZG4ubmV0J10sIG9yaWdpbjogJ2h0dHBzOi8vd3d3Lmluc3RhZ3JhbS5jb20nIH0sXHJcbiAgeyBkb21haW5zOiBbJ3R3aXRjaC50dicsICd0dHZudy5uZXQnLCAnanR2bncubmV0JywgJ2Nsb3VkZnJvbnQubmV0J10sIG9yaWdpbjogJ2h0dHBzOi8vd3d3LnR3aXRjaC50dicgfSxcclxuICB7IGRvbWFpbnM6IFsndHdpbWcuY29tJ10sIG9yaWdpbjogJ2h0dHBzOi8veC5jb20nIH0sXHJcbiAgLi4uKF9fQlVJTERfXyA9PT0gJ2Z1bGwnID8gW3sgZG9tYWluczogWyd5b3V0dWJlLmNvbScsICdnb29nbGV2aWRlby5jb20nXSwgb3JpZ2luOiAnaHR0cHM6Ly93d3cueW91dHViZS5jb20nIH1dIDogW10pLFxyXG5dO1xyXG5cclxuYXN5bmMgZnVuY3Rpb24gaW5zdGFsbEhlYWRlclJ1bGVzKCkge1xyXG4gIC8vIFRocmVlIHJ1bGVzIHBlciBwbGF0Zm9ybTogcmVxdWVzdHMgd2l0aCBubyB0YWIgKG9mZnNjcmVlbiksIHJlcXVlc3RzIG1hZGUgYnkgb3VyIHJlbGF5IGlmcmFtZSBpbnNpZGUgYVxyXG4gIC8vIHNpdGUgdGFiLCBhbmQgdGhlIHByZXZpZXcgPHZpZGVvPi88aW1nPiBvbiB0aGUgQ2xpcEZsb3cgc2l0ZSBpdHNlbGYgKENETnMgbGlrZSB2aWRlby50d2ltZy5jb20gYW5zd2VyIDQwM1xyXG4gIC8vIHRvIGEgbG9jYWxob3N0IC8gY2xpcGZsb3cgUmVmZXJlcikuXHJcbiAgY29uc3Qgc2l0ZUhvc3RzID0gX19TSVRFX09SSUdJTlNfXy5tYXAoKG8pID0+IG5ldyBVUkwobykuaG9zdG5hbWUpO1xyXG4gIGNvbnN0IGNvbmRpdGlvbnMgPSAoZG9tYWluczogc3RyaW5nW10pOiBjaHJvbWUuZGVjbGFyYXRpdmVOZXRSZXF1ZXN0LlJ1bGVDb25kaXRpb25bXSA9PiBbXHJcbiAgICB7IHJlcXVlc3REb21haW5zOiBkb21haW5zLCB0YWJJZHM6IFtjaHJvbWUudGFicy5UQUJfSURfTk9ORV0gfSxcclxuICAgIHsgcmVxdWVzdERvbWFpbnM6IGRvbWFpbnMsIGluaXRpYXRvckRvbWFpbnM6IFtjaHJvbWUucnVudGltZS5pZF0gfSxcclxuICAgIHtcclxuICAgICAgcmVxdWVzdERvbWFpbnM6IGRvbWFpbnMsIGluaXRpYXRvckRvbWFpbnM6IHNpdGVIb3N0cyxcclxuICAgICAgcmVzb3VyY2VUeXBlczogW2Nocm9tZS5kZWNsYXJhdGl2ZU5ldFJlcXVlc3QuUmVzb3VyY2VUeXBlLk1FRElBLCBjaHJvbWUuZGVjbGFyYXRpdmVOZXRSZXF1ZXN0LlJlc291cmNlVHlwZS5JTUFHRV0sXHJcbiAgICB9LFxyXG4gIF07XHJcbiAgY29uc3QgcnVsZXM6IGNocm9tZS5kZWNsYXJhdGl2ZU5ldFJlcXVlc3QuUnVsZVtdID0gSEVBREVSX1JVTEVTLmZsYXRNYXAoKHIpID0+IGNvbmRpdGlvbnMoci5kb21haW5zKS5tYXAoKGNvbmRpdGlvbikgPT4gKHsgciwgY29uZGl0aW9uIH0pKSlcclxuICAgIC5tYXAoKHsgciwgY29uZGl0aW9uIH0sIGkpID0+ICh7XHJcbiAgICBpZDogaSArIDEsXHJcbiAgICBwcmlvcml0eTogMSxcclxuICAgIGFjdGlvbjoge1xyXG4gICAgICB0eXBlOiBjaHJvbWUuZGVjbGFyYXRpdmVOZXRSZXF1ZXN0LlJ1bGVBY3Rpb25UeXBlLk1PRElGWV9IRUFERVJTLFxyXG4gICAgICByZXF1ZXN0SGVhZGVyczogW1xyXG4gICAgICAgIHsgaGVhZGVyOiAncmVmZXJlcicsIG9wZXJhdGlvbjogY2hyb21lLmRlY2xhcmF0aXZlTmV0UmVxdWVzdC5IZWFkZXJPcGVyYXRpb24uU0VULCB2YWx1ZTogYCR7ci5vcmlnaW59L2AgfSxcclxuICAgICAgICB7IGhlYWRlcjogJ29yaWdpbicsIG9wZXJhdGlvbjogY2hyb21lLmRlY2xhcmF0aXZlTmV0UmVxdWVzdC5IZWFkZXJPcGVyYXRpb24uU0VULCB2YWx1ZTogci5vcmlnaW4gfSxcclxuICAgICAgXSxcclxuICAgIH0sXHJcbiAgICBjb25kaXRpb24sXHJcbiAgfSkpO1xyXG4gIGF3YWl0IGNocm9tZS5kZWNsYXJhdGl2ZU5ldFJlcXVlc3QudXBkYXRlU2Vzc2lvblJ1bGVzKHtcclxuICAgIHJlbW92ZVJ1bGVJZHM6IChhd2FpdCBjaHJvbWUuZGVjbGFyYXRpdmVOZXRSZXF1ZXN0LmdldFNlc3Npb25SdWxlcygpKS5tYXAoKHIpID0+IHIuaWQpLFxyXG4gICAgYWRkUnVsZXM6IHJ1bGVzLFxyXG4gIH0pO1xyXG59XHJcblxyXG5jaHJvbWUucnVudGltZS5vbkluc3RhbGxlZC5hZGRMaXN0ZW5lcigoKSA9PiB2b2lkIGluc3RhbGxIZWFkZXJSdWxlcygpKTtcclxuY2hyb21lLnJ1bnRpbWUub25TdGFydHVwLmFkZExpc3RlbmVyKCgpID0+IHZvaWQgaW5zdGFsbEhlYWRlclJ1bGVzKCkpO1xyXG5cclxuY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChtc2csIF9zZW5kZXIsIHNlbmRSZXNwb25zZSkgPT4ge1xyXG4gIGlmIChtc2c/LnRhcmdldCAhPT0gJ2JnJykgcmV0dXJuO1xyXG4gIChhc3luYyAoKSA9PiB7XHJcbiAgICBzd2l0Y2ggKG1zZy50eXBlKSB7XHJcbiAgICAgIGNhc2UgJ2Vuc3VyZU9mZnNjcmVlbic6XHJcbiAgICAgICAgYXdhaXQgaW5zdGFsbEhlYWRlclJ1bGVzKCk7XHJcbiAgICAgICAgYXdhaXQgZW5zdXJlT2Zmc2NyZWVuKCk7XHJcbiAgICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcclxuICAgICAgY2FzZSAnZ2V0Q29va2llcyc6IHtcclxuICAgICAgICBjb25zdCBhbGwgPSBhd2FpdCBjaHJvbWUuY29va2llcy5nZXRBbGwoeyB1cmw6IG1zZy51cmwgfSk7XHJcbiAgICAgICAgcmV0dXJuIHsgaGVhZGVyOiBhbGwubWFwKChjKSA9PiBgJHtjLm5hbWV9PSR7Yy52YWx1ZX1gKS5qb2luKCc7ICcpIH07XHJcbiAgICAgIH1cclxuICAgICAgY2FzZSAnZ2V0Q29va2llJzoge1xyXG4gICAgICAgIGNvbnN0IGMgPSBhd2FpdCBjaHJvbWUuY29va2llcy5nZXQoeyB1cmw6IG1zZy51cmwsIG5hbWU6IG1zZy5uYW1lIH0pO1xyXG4gICAgICAgIHJldHVybiB7IHZhbHVlOiBjPy52YWx1ZSA/PyBudWxsIH07XHJcbiAgICAgIH1cclxuICAgICAgY2FzZSAnc2F2ZUZpbGUnOlxyXG4gICAgICAgIGNvbnNvbGUubG9nKGBbQ2xpcEZsb3cgYmddIHNhdmluZyAke21zZy5maWxlbmFtZX1gKTtcclxuICAgICAgICByZXR1cm4gc2F2ZUFuZFdhaXQobXNnLnVybCwgbXNnLmZpbGVuYW1lKTtcclxuICAgIH1cclxuICB9KSgpLnRoZW4oc2VuZFJlc3BvbnNlLCAoZXJyKSA9PiBzZW5kUmVzcG9uc2UoeyBlcnJvcjogU3RyaW5nKGVycj8ubWVzc2FnZSB8fCBlcnIpIH0pKTtcclxuICByZXR1cm4gdHJ1ZTtcclxufSk7XHJcblxyXG4vKiogU2F2ZXMgdmlhIGNocm9tZS5kb3dubG9hZHMgYW5kIHJlc29sdmVzIG9ubHkgb25jZSB0aGUgZmlsZSBpcyBmdWxseSB3cml0dGVuIChvciBmYWlscykuICovXHJcbmZ1bmN0aW9uIHNhdmVBbmRXYWl0KHVybDogc3RyaW5nLCBmaWxlbmFtZTogc3RyaW5nKTogUHJvbWlzZTx7IGRvd25sb2FkSWQ/OiBudW1iZXI7IGVycm9yPzogc3RyaW5nIH0+IHtcclxuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcclxuICAgIGxldCBkb3dubG9hZElkOiBudW1iZXIgfCB1bmRlZmluZWQ7XHJcbiAgICBjb25zdCBlYXJseTogY2hyb21lLmRvd25sb2Fkcy5Eb3dubG9hZERlbHRhW10gPSBbXTsgLy8gZGVsdGFzIHRoYXQgYXJyaXZlIGJlZm9yZSBkb3dubG9hZCgpIHJldHVybnMgdGhlIGlkXHJcbiAgICBjb25zdCBmaW5pc2ggPSAocjogeyBkb3dubG9hZElkPzogbnVtYmVyOyBlcnJvcj86IHN0cmluZyB9KSA9PiB7XHJcbiAgICAgIGNocm9tZS5kb3dubG9hZHMub25DaGFuZ2VkLnJlbW92ZUxpc3RlbmVyKG9uQ2hhbmdlZCk7XHJcbiAgICAgIC8vIEZyZWUgdGhlIG9mZnNjcmVlbiBibG9iIG5vdyB0aGF0IENocm9tZSBpcyBkb25lIHdpdGggaXQuXHJcbiAgICAgIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdGFyZ2V0OiAnb2Zmc2NyZWVuJywgdHlwZTogJ3Jldm9rZScsIHVybCB9KS5jYXRjaCgoKSA9PiB7fSk7XHJcbiAgICAgIHJlc29sdmUocik7XHJcbiAgICB9O1xyXG4gICAgY29uc3Qgb25DaGFuZ2VkID0gKGQ6IGNocm9tZS5kb3dubG9hZHMuRG93bmxvYWREZWx0YSkgPT4ge1xyXG4gICAgICBpZiAoZG93bmxvYWRJZCA9PT0gdW5kZWZpbmVkKSB7IGVhcmx5LnB1c2goZCk7IHJldHVybjsgfVxyXG4gICAgICBpZiAoZC5pZCAhPT0gZG93bmxvYWRJZCkgcmV0dXJuO1xyXG4gICAgICBpZiAoZC5zdGF0ZT8uY3VycmVudCA9PT0gJ2NvbXBsZXRlJykgeyBjb25zb2xlLmxvZyhgW0NsaXBGbG93IGJnXSBzYXZlZCAjJHtkb3dubG9hZElkfWApOyBmaW5pc2goeyBkb3dubG9hZElkIH0pOyB9XHJcbiAgICAgIGVsc2UgaWYgKGQuc3RhdGU/LmN1cnJlbnQgPT09ICdpbnRlcnJ1cHRlZCcpIGZpbmlzaCh7IGVycm9yOiBgU2F2aW5nIGZhaWxlZDogJHtkLmVycm9yPy5jdXJyZW50IHx8ICdpbnRlcnJ1cHRlZCd9YCB9KTtcclxuICAgIH07XHJcbiAgICBjaHJvbWUuZG93bmxvYWRzLm9uQ2hhbmdlZC5hZGRMaXN0ZW5lcihvbkNoYW5nZWQpO1xyXG4gICAgLy8gQ2hyb21lIG9jY2FzaW9uYWxseSBhY2NlcHRzIGEgZG93bmxvYWQoKSBjYWxsIGJ1dCBuZXZlciBjcmVhdGVzIHRoZSBkb3dubG9hZCAobm8gaXRlbSwgbm8gZXJyb3IpLlxyXG4gICAgLy8gSWYgbm90aGluZyBoYXMgc3RhcnRlZCBhZnRlciAxNSBzLCByZXRyeSBvbmNlIHdpdGggYSBwbGFpbi1BU0NJSSBuYW1lLCB0aGVuIGdpdmUgdXAgd2l0aCBhIGNsZWFyIGVycm9yLlxyXG4gICAgbGV0IHNldHRsZWQgPSBmYWxzZTtcclxuICAgIGNvbnN0IGF0dGVtcHQgPSAobmFtZTogc3RyaW5nLCByZXRyeTogYm9vbGVhbikgPT4ge1xyXG4gICAgICBjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIGlmIChzZXR0bGVkKSByZXR1cm47XHJcbiAgICAgICAgY29uc29sZS53YXJuKGBbQ2xpcEZsb3cgYmddIGRvd25sb2FkIG9mIFwiJHtuYW1lfVwiIGRpZCBub3Qgc3RhcnQgaW4gMTVzJHtyZXRyeSA/ICcsIHJldHJ5aW5nJyA6ICcnfWApO1xyXG4gICAgICAgIGlmIChyZXRyeSkgYXR0ZW1wdChhc2NpaU5hbWUobmFtZSksIGZhbHNlKTtcclxuICAgICAgICBlbHNlIHsgc2V0dGxlZCA9IHRydWU7IGZpbmlzaCh7IGVycm9yOiAnQ2hyb21lIGRpZCBub3Qgc3RhcnQgdGhlIGRvd25sb2FkLiBQbGVhc2UgY2xpY2sgRG93bmxvYWQgYWdhaW4uJyB9KTsgfVxyXG4gICAgICB9LCAxNV8wMDApO1xyXG4gICAgICBjaHJvbWUuZG93bmxvYWRzLmRvd25sb2FkKHsgdXJsLCBmaWxlbmFtZTogbmFtZSwgc2F2ZUFzOiBmYWxzZSwgY29uZmxpY3RBY3Rpb246ICd1bmlxdWlmeScgfSkudGhlbihcclxuICAgICAgICAoaWQpID0+IHtcclxuICAgICAgICAgIGNsZWFyVGltZW91dCh0aW1lcik7XHJcbiAgICAgICAgICBpZiAoc2V0dGxlZCkgeyBjaHJvbWUuZG93bmxvYWRzLmNhbmNlbChpZCkuY2F0Y2goKCkgPT4ge30pOyByZXR1cm47IH0gICAvLyBhIGxhdGUgZHVwbGljYXRlIG9mIGEgcmV0cmllZCBjYWxsXHJcbiAgICAgICAgICBzZXR0bGVkID0gdHJ1ZTtcclxuICAgICAgICAgIGRvd25sb2FkSWQgPSBpZDtcclxuICAgICAgICAgIGVhcmx5LmZvckVhY2gob25DaGFuZ2VkKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIChlcnIpID0+IHtcclxuICAgICAgICAgIGNsZWFyVGltZW91dCh0aW1lcik7XHJcbiAgICAgICAgICBpZiAoc2V0dGxlZCkgcmV0dXJuO1xyXG4gICAgICAgICAgc2V0dGxlZCA9IHRydWU7XHJcbiAgICAgICAgICBjb25zb2xlLndhcm4oJ1tDbGlwRmxvdyBiZ10gY2hyb21lLmRvd25sb2FkcyBmYWlsZWQ6JywgZXJyPy5tZXNzYWdlIHx8IGVycik7XHJcbiAgICAgICAgICBmaW5pc2goeyBlcnJvcjogYFNhdmluZyBmYWlsZWQ6ICR7ZXJyPy5tZXNzYWdlIHx8IGVycn1gIH0pO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICk7XHJcbiAgICB9O1xyXG4gICAgYXR0ZW1wdChmaWxlbmFtZSwgdHJ1ZSk7XHJcbiAgfSk7XHJcbn1cclxuXHJcbi8qKiBcIklyb24gTWFuLCBNYXJrIDEtODUgXHVEODNEXHVERDI1Lm1wM1wiIFx1MjE5MiBcIklyb24gTWFuLCBNYXJrIDEtODUubXAzXCIgKGZhbGxiYWNrIG5hbWUgZm9yIHRoZSByZXRyeSkuICovXHJcbmZ1bmN0aW9uIGFzY2lpTmFtZShuYW1lOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gIGNvbnN0IGRvdCA9IG5hbWUubGFzdEluZGV4T2YoJy4nKTtcclxuICBjb25zdCBiYXNlID0gKGRvdCA+IDAgPyBuYW1lLnNsaWNlKDAsIGRvdCkgOiBuYW1lKS5yZXBsYWNlKC9bXlxceDIwLVxceDdFXS9nLCAnJykucmVwbGFjZSgvXFxzKy9nLCAnICcpLnRyaW0oKSB8fCAnQ2xpcEZsb3cgY2xpcCc7XHJcbiAgcmV0dXJuIGRvdCA+IDAgPyBiYXNlICsgbmFtZS5zbGljZShkb3QpIDogYmFzZTtcclxufVxyXG5cclxuLy8gQWZ0ZXIgaW5zdGFsbCAvIHVwZGF0ZSwgb3BlbiBDbGlwRmxvdyB0YWJzIGRvbid0IGhhdmUgdGhlIGNvbnRlbnQgc2NyaXB0IHlldCAoQ2hyb21lIG9ubHkgaW5qZWN0c1xyXG4vLyBkZWNsYXJlZCBjb250ZW50IHNjcmlwdHMgaW50byBwYWdlcyBsb2FkZWQgYWZ0ZXJ3YXJkcykgXHUyMDE0IGluamVjdCBpdCBzbyB0aGUgc2l0ZSBzZWVzIHRoZSBleHRlbnNpb25cclxuLy8gaW1tZWRpYXRlbHksIHdpdGhvdXQgYSBwYWdlIHJlbG9hZC5cclxuY2hyb21lLnJ1bnRpbWUub25JbnN0YWxsZWQuYWRkTGlzdGVuZXIoYXN5bmMgKCkgPT4ge1xyXG4gIGNvbnN0IG1hdGNoZXMgPSBjaHJvbWUucnVudGltZS5nZXRNYW5pZmVzdCgpLmNvbnRlbnRfc2NyaXB0cz8uWzBdPy5tYXRjaGVzID8/IFtdO1xyXG4gIGNvbnN0IHRhYnMgPSBhd2FpdCBjaHJvbWUudGFicy5xdWVyeSh7IHVybDogbWF0Y2hlcyB9KTtcclxuICBmb3IgKGNvbnN0IHRhYiBvZiB0YWJzKSB7XHJcbiAgICBpZiAoIXRhYi5pZCkgY29udGludWU7XHJcbiAgICBjaHJvbWUuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoeyB0YXJnZXQ6IHsgdGFiSWQ6IHRhYi5pZCB9LCBmaWxlczogWydjb250ZW50LmpzJ10gfSlcclxuICAgICAgLnRoZW4oKCkgPT4gY29uc29sZS5sb2coYFtDbGlwRmxvdyBiZ10gaW5qZWN0ZWQgaW50byBvcGVuIHRhYiAke3RhYi51cmx9YCkpXHJcbiAgICAgIC5jYXRjaCgoZXJyKSA9PiBjb25zb2xlLndhcm4oJ1tDbGlwRmxvdyBiZ10gaW5qZWN0IGZhaWxlZDonLCB0YWIudXJsLCBlcnI/Lm1lc3NhZ2UpKTtcclxuICB9XHJcbn0pO1xyXG5cclxuLy8gRGVidWc6IGxvZyBldmVyeSBoZWFkZXItcmV3cml0ZSBtYXRjaCAob25seSBhdmFpbGFibGUgZm9yIHVucGFja2VkIGV4dGVuc2lvbnMgd2l0aFxyXG4vLyBkZWNsYXJhdGl2ZU5ldFJlcXVlc3RGZWVkYmFjaykuIElmIFlvdVR1YmUgcmV0dXJucyA0MDMgYW5kIG5vdGhpbmcgaXMgbG9nZ2VkIGhlcmUsIHRoZVxyXG4vLyBPcmlnaW4vUmVmZXJlciByZXdyaXRlIGlzbid0IGJlaW5nIGFwcGxpZWQgaW4gdGhpcyBicm93c2VyLlxyXG5jaHJvbWUuZGVjbGFyYXRpdmVOZXRSZXF1ZXN0Lm9uUnVsZU1hdGNoZWREZWJ1Zz8uYWRkTGlzdGVuZXIoKGluZm8pID0+IHtcclxuICBjb25zb2xlLmxvZyhgW0NsaXBGbG93IGJnXSBoZWFkZXIgcnVsZSAke2luZm8ucnVsZS5ydWxlSWR9IGFwcGxpZWQgXHUyMTkyICR7aW5mby5yZXF1ZXN0LnVybC5zcGxpdCgnPycpWzBdfWApO1xyXG59KTtcclxuY2hyb21lLmRlY2xhcmF0aXZlTmV0UmVxdWVzdC5nZXRTZXNzaW9uUnVsZXMoKS50aGVuKChydWxlcykgPT4gY29uc29sZS5sb2coYFtDbGlwRmxvdyBiZ10gJHtydWxlcy5sZW5ndGh9IGhlYWRlciBydWxlcyBhY3RpdmVgKSk7XHJcbiJdLAogICJtYXBwaW5ncyI6ICI7QUFBQSxtQ0FBQyxvQ0FBbUMseUJBQXdCLHlCQUF3Qix5QkFBd0IsNEJBQTJCLGdDQUFnQzs7O0FDR3ZLLElBQU0sZ0JBQWdCO0FBRXRCLGVBQWUsa0JBQWtCO0FBQy9CLFFBQU0sV0FBVyxNQUFNLE9BQU8sUUFBUSxZQUFZLEVBQUUsY0FBYyxDQUFDLE9BQU8sUUFBUSxZQUFZLGtCQUFrQixFQUFFLENBQUM7QUFDbkgsTUFBSSxTQUFTLE9BQVE7QUFDckIsTUFBSTtBQUNGLFVBQU0sT0FBTyxVQUFVLGVBQWU7QUFBQSxNQUNwQyxLQUFLO0FBQUEsTUFDTCxTQUFTLENBQUMsT0FBTyxVQUFVLE9BQU8sU0FBUyxPQUFPLFVBQVUsT0FBTyxLQUFLO0FBQUEsTUFDeEUsZUFBZTtBQUFBLElBQ2pCLENBQUM7QUFBQSxFQUNILFNBQVMsS0FBVTtBQUNqQixRQUFJLENBQUMsT0FBTyxLQUFLLE9BQU8sRUFBRSxTQUFTLGtCQUFrQixFQUFHLE9BQU07QUFBQSxFQUNoRTtBQUNGO0FBR0EsSUFBTSxlQUE2RDtBQUFBLEVBQ2pFLEVBQUUsU0FBUyxDQUFDLGlCQUFpQixvQkFBb0IsV0FBVyxHQUFHLFFBQVEsNEJBQTRCO0FBQUEsRUFDbkcsRUFBRSxTQUFTLENBQUMsYUFBYSxhQUFhLGFBQWEsZ0JBQWdCLEdBQUcsUUFBUSx3QkFBd0I7QUFBQSxFQUN0RyxFQUFFLFNBQVMsQ0FBQyxXQUFXLEdBQUcsUUFBUSxnQkFBZ0I7QUFBQSxFQUNsRCxHQUFJLE9BQXVCLENBQUMsRUFBRSxTQUFTLENBQUMsZUFBZSxpQkFBaUIsR0FBRyxRQUFRLDBCQUEwQixDQUFDLElBQUksQ0FBQztBQUNySDtBQUVBLGVBQWUscUJBQXFCO0FBSWxDLFFBQU0sWUFBWSw0QkFBaUIsSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsRUFBRSxRQUFRO0FBQ2pFLFFBQU0sYUFBYSxDQUFDLFlBQW9FO0FBQUEsSUFDdEYsRUFBRSxnQkFBZ0IsU0FBUyxRQUFRLENBQUMsT0FBTyxLQUFLLFdBQVcsRUFBRTtBQUFBLElBQzdELEVBQUUsZ0JBQWdCLFNBQVMsa0JBQWtCLENBQUMsT0FBTyxRQUFRLEVBQUUsRUFBRTtBQUFBLElBQ2pFO0FBQUEsTUFDRSxnQkFBZ0I7QUFBQSxNQUFTLGtCQUFrQjtBQUFBLE1BQzNDLGVBQWUsQ0FBQyxPQUFPLHNCQUFzQixhQUFhLE9BQU8sT0FBTyxzQkFBc0IsYUFBYSxLQUFLO0FBQUEsSUFDbEg7QUFBQSxFQUNGO0FBQ0EsUUFBTSxRQUE2QyxhQUFhLFFBQVEsQ0FBQyxNQUFNLFdBQVcsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLGVBQWUsRUFBRSxHQUFHLFVBQVUsRUFBRSxDQUFDLEVBQ3hJLElBQUksQ0FBQyxFQUFFLEdBQUcsVUFBVSxHQUFHLE9BQU87QUFBQSxJQUMvQixJQUFJLElBQUk7QUFBQSxJQUNSLFVBQVU7QUFBQSxJQUNWLFFBQVE7QUFBQSxNQUNOLE1BQU0sT0FBTyxzQkFBc0IsZUFBZTtBQUFBLE1BQ2xELGdCQUFnQjtBQUFBLFFBQ2QsRUFBRSxRQUFRLFdBQVcsV0FBVyxPQUFPLHNCQUFzQixnQkFBZ0IsS0FBSyxPQUFPLEdBQUcsRUFBRSxNQUFNLElBQUk7QUFBQSxRQUN4RyxFQUFFLFFBQVEsVUFBVSxXQUFXLE9BQU8sc0JBQXNCLGdCQUFnQixLQUFLLE9BQU8sRUFBRSxPQUFPO0FBQUEsTUFDbkc7QUFBQSxJQUNGO0FBQUEsSUFDQTtBQUFBLEVBQ0YsRUFBRTtBQUNGLFFBQU0sT0FBTyxzQkFBc0IsbUJBQW1CO0FBQUEsSUFDcEQsZ0JBQWdCLE1BQU0sT0FBTyxzQkFBc0IsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxFQUFFO0FBQUEsSUFDckYsVUFBVTtBQUFBLEVBQ1osQ0FBQztBQUNIO0FBRUEsT0FBTyxRQUFRLFlBQVksWUFBWSxNQUFNLEtBQUssbUJBQW1CLENBQUM7QUFDdEUsT0FBTyxRQUFRLFVBQVUsWUFBWSxNQUFNLEtBQUssbUJBQW1CLENBQUM7QUFFcEUsT0FBTyxRQUFRLFVBQVUsWUFBWSxDQUFDLEtBQUssU0FBUyxpQkFBaUI7QUFDbkUsTUFBSSxLQUFLLFdBQVcsS0FBTTtBQUMxQixHQUFDLFlBQVk7QUFDWCxZQUFRLElBQUksTUFBTTtBQUFBLE1BQ2hCLEtBQUs7QUFDSCxjQUFNLG1CQUFtQjtBQUN6QixjQUFNLGdCQUFnQjtBQUN0QixlQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsTUFDcEIsS0FBSyxjQUFjO0FBQ2pCLGNBQU0sTUFBTSxNQUFNLE9BQU8sUUFBUSxPQUFPLEVBQUUsS0FBSyxJQUFJLElBQUksQ0FBQztBQUN4RCxlQUFPLEVBQUUsUUFBUSxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsRUFBRSxJQUFJLElBQUksRUFBRSxLQUFLLEVBQUUsRUFBRSxLQUFLLElBQUksRUFBRTtBQUFBLE1BQ3JFO0FBQUEsTUFDQSxLQUFLLGFBQWE7QUFDaEIsY0FBTSxJQUFJLE1BQU0sT0FBTyxRQUFRLElBQUksRUFBRSxLQUFLLElBQUksS0FBSyxNQUFNLElBQUksS0FBSyxDQUFDO0FBQ25FLGVBQU8sRUFBRSxPQUFPLEdBQUcsU0FBUyxLQUFLO0FBQUEsTUFDbkM7QUFBQSxNQUNBLEtBQUs7QUFDSCxnQkFBUSxJQUFJLHdCQUF3QixJQUFJLFFBQVEsRUFBRTtBQUNsRCxlQUFPLFlBQVksSUFBSSxLQUFLLElBQUksUUFBUTtBQUFBLElBQzVDO0FBQUEsRUFDRixHQUFHLEVBQUUsS0FBSyxjQUFjLENBQUMsUUFBUSxhQUFhLEVBQUUsT0FBTyxPQUFPLEtBQUssV0FBVyxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ3JGLFNBQU87QUFDVCxDQUFDO0FBR0QsU0FBUyxZQUFZLEtBQWEsVUFBb0U7QUFDcEcsU0FBTyxJQUFJLFFBQVEsQ0FBQyxZQUFZO0FBQzlCLFFBQUk7QUFDSixVQUFNLFFBQTBDLENBQUM7QUFDakQsVUFBTSxTQUFTLENBQUMsTUFBK0M7QUFDN0QsYUFBTyxVQUFVLFVBQVUsZUFBZSxTQUFTO0FBRW5ELGFBQU8sUUFBUSxZQUFZLEVBQUUsUUFBUSxhQUFhLE1BQU0sVUFBVSxJQUFJLENBQUMsRUFBRSxNQUFNLE1BQU07QUFBQSxNQUFDLENBQUM7QUFDdkYsY0FBUSxDQUFDO0FBQUEsSUFDWDtBQUNBLFVBQU0sWUFBWSxDQUFDLE1BQXNDO0FBQ3ZELFVBQUksZUFBZSxRQUFXO0FBQUUsY0FBTSxLQUFLLENBQUM7QUFBRztBQUFBLE1BQVE7QUFDdkQsVUFBSSxFQUFFLE9BQU8sV0FBWTtBQUN6QixVQUFJLEVBQUUsT0FBTyxZQUFZLFlBQVk7QUFBRSxnQkFBUSxJQUFJLHdCQUF3QixVQUFVLEVBQUU7QUFBRyxlQUFPLEVBQUUsV0FBVyxDQUFDO0FBQUEsTUFBRyxXQUN6RyxFQUFFLE9BQU8sWUFBWSxjQUFlLFFBQU8sRUFBRSxPQUFPLGtCQUFrQixFQUFFLE9BQU8sV0FBVyxhQUFhLEdBQUcsQ0FBQztBQUFBLElBQ3RIO0FBQ0EsV0FBTyxVQUFVLFVBQVUsWUFBWSxTQUFTO0FBR2hELFFBQUksVUFBVTtBQUNkLFVBQU0sVUFBVSxDQUFDLE1BQWMsVUFBbUI7QUFDaEQsWUFBTSxRQUFRLFdBQVcsTUFBTTtBQUM3QixZQUFJLFFBQVM7QUFDYixnQkFBUSxLQUFLLDhCQUE4QixJQUFJLHlCQUF5QixRQUFRLGVBQWUsRUFBRSxFQUFFO0FBQ25HLFlBQUksTUFBTyxTQUFRLFVBQVUsSUFBSSxHQUFHLEtBQUs7QUFBQSxhQUNwQztBQUFFLG9CQUFVO0FBQU0saUJBQU8sRUFBRSxPQUFPLGtFQUFrRSxDQUFDO0FBQUEsUUFBRztBQUFBLE1BQy9HLEdBQUcsSUFBTTtBQUNULGFBQU8sVUFBVSxTQUFTLEVBQUUsS0FBSyxVQUFVLE1BQU0sUUFBUSxPQUFPLGdCQUFnQixXQUFXLENBQUMsRUFBRTtBQUFBLFFBQzVGLENBQUMsT0FBTztBQUNOLHVCQUFhLEtBQUs7QUFDbEIsY0FBSSxTQUFTO0FBQUUsbUJBQU8sVUFBVSxPQUFPLEVBQUUsRUFBRSxNQUFNLE1BQU07QUFBQSxZQUFDLENBQUM7QUFBRztBQUFBLFVBQVE7QUFDcEUsb0JBQVU7QUFDVix1QkFBYTtBQUNiLGdCQUFNLFFBQVEsU0FBUztBQUFBLFFBQ3pCO0FBQUEsUUFDQSxDQUFDLFFBQVE7QUFDUCx1QkFBYSxLQUFLO0FBQ2xCLGNBQUksUUFBUztBQUNiLG9CQUFVO0FBQ1Ysa0JBQVEsS0FBSywwQ0FBMEMsS0FBSyxXQUFXLEdBQUc7QUFDMUUsaUJBQU8sRUFBRSxPQUFPLGtCQUFrQixLQUFLLFdBQVcsR0FBRyxHQUFHLENBQUM7QUFBQSxRQUMzRDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsWUFBUSxVQUFVLElBQUk7QUFBQSxFQUN4QixDQUFDO0FBQ0g7QUFHQSxTQUFTLFVBQVUsTUFBc0I7QUFDdkMsUUFBTSxNQUFNLEtBQUssWUFBWSxHQUFHO0FBQ2hDLFFBQU0sUUFBUSxNQUFNLElBQUksS0FBSyxNQUFNLEdBQUcsR0FBRyxJQUFJLE1BQU0sUUFBUSxpQkFBaUIsRUFBRSxFQUFFLFFBQVEsUUFBUSxHQUFHLEVBQUUsS0FBSyxLQUFLO0FBQy9HLFNBQU8sTUFBTSxJQUFJLE9BQU8sS0FBSyxNQUFNLEdBQUcsSUFBSTtBQUM1QztBQUtBLE9BQU8sUUFBUSxZQUFZLFlBQVksWUFBWTtBQUNqRCxRQUFNLFVBQVUsT0FBTyxRQUFRLFlBQVksRUFBRSxrQkFBa0IsQ0FBQyxHQUFHLFdBQVcsQ0FBQztBQUMvRSxRQUFNLE9BQU8sTUFBTSxPQUFPLEtBQUssTUFBTSxFQUFFLEtBQUssUUFBUSxDQUFDO0FBQ3JELGFBQVcsT0FBTyxNQUFNO0FBQ3RCLFFBQUksQ0FBQyxJQUFJLEdBQUk7QUFDYixXQUFPLFVBQVUsY0FBYyxFQUFFLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRyxHQUFHLE9BQU8sQ0FBQyxZQUFZLEVBQUUsQ0FBQyxFQUNoRixLQUFLLE1BQU0sUUFBUSxJQUFJLHdDQUF3QyxJQUFJLEdBQUcsRUFBRSxDQUFDLEVBQ3pFLE1BQU0sQ0FBQyxRQUFRLFFBQVEsS0FBSyxnQ0FBZ0MsSUFBSSxLQUFLLEtBQUssT0FBTyxDQUFDO0FBQUEsRUFDdkY7QUFDRixDQUFDO0FBS0QsT0FBTyxzQkFBc0Isb0JBQW9CLFlBQVksQ0FBQyxTQUFTO0FBQ3JFLFVBQVEsSUFBSSw2QkFBNkIsS0FBSyxLQUFLLE1BQU0sbUJBQWMsS0FBSyxRQUFRLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUU7QUFDekcsQ0FBQztBQUNELE9BQU8sc0JBQXNCLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxVQUFVLFFBQVEsSUFBSSxpQkFBaUIsTUFBTSxNQUFNLHNCQUFzQixDQUFDOyIsCiAgIm5hbWVzIjogW10KfQo=
